import express from "express";
import Parser from "rss-parser";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { cleanText, normalizeText, isValidStandingTable, finalResult, mapOpenLigaMatch, mapOpenFootballMatch, dedupeNews, reconcileMatches } from "./lib/logic.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
try { process.loadEnvFile(path.join(__dirname, ".env")); } catch { /* optional local environment file */ }
const app = express();
const PORT = Number(process.env.PORT || 3000);
const OPENLIGA = "https://api.openligadb.de";
const FOOTBALL_DATA = "https://api.football-data.org/v4";
const ESPN = "https://site.api.espn.com/apis/site/v2/sports/soccer";
const SPORTScore = "https://sportscore.com";
const VERSION = "9.0.0";
const NEWS_REFRESH_MS = 10 * 60 * 1000;
const DATA_REFRESH_MS = 5 * 60 * 1000;
const CURRENT_SEASON = Number(process.env.SEASON || new Date().getFullYear());
const sourceList = JSON.parse(await fs.readFile(path.join(__dirname, "sources.json"), "utf8"));
const parser = new Parser({ timeout: 12000, headers: { "User-Agent": `DOKSAN/${VERSION} (football news portal)` } });

const FD_COMPETITIONS = [
  ["PL", "Premier League", "England"], ["PD", "La Liga", "Spain"], ["BL1", "Bundesliga", "Germany"],
  ["SA", "Serie A", "Italy"], ["FL1", "Ligue 1", "France"], ["DED", "Eredivisie", "Netherlands"],
  ["PPL", "Primeira Liga", "Portugal"], ["CL", "UEFA Champions League", "Europe"],
  ["ELC", "Championship", "England"], ["BSA", "Brasileirão Série A", "Brazil"],
  ["WC", "FIFA World Cup", "World"], ["EC", "UEFA European Championship", "Europe"]
];
const OPENFOOTBALL_MAP = {
  "eng.1":"en.1","esp.1":"es.1","ger.1":"de.1","ita.1":"it.1","fra.1":"fr.1","ned.1":"nl.1","por.1":"pt.1",
  "PL":"en.1","PD":"es.1","BL1":"de.1","SA":"it.1","FL1":"fr.1","DED":"nl.1","PPL":"pt.1"
};
const ESPN_COMPETITIONS = [
  ["tur.1","Trendyol Süper Lig","Türkiye"],["eng.1","Premier League","İngiltere"],["esp.1","La Liga","İspanya"],["ger.1","Bundesliga","Almanya"],["ita.1","Serie A","İtalya"],["fra.1","Ligue 1","Fransa"],["uefa.champions","UEFA Champions League","Avrupa"],["uefa.europa","UEFA Europa League","Avrupa"],["uefa.europa.conf","UEFA Conference League","Avrupa"],["ned.1","Eredivisie","Hollanda"],["por.1","Primeira Liga","Portekiz"],["usa.1","MLS","ABD"]
];

const BREAKING = /(son dakika|az önce|resmen açıklandı|resmi açıklama|son gelişme|acil)/i;
const TRANSFER = /(transfer|transf(er|er)i|imza|kiral(ık|ik)|bonservis|serbest kal|sözleşme|kontrat|takımdan ayrıl|anlaşma sağla|anlaştı|resmi teklif|teklif yaptı|görüşme|menajer|satın alma opsiyon)/i;
const FOOTBALL = /(football|soccer|futbol|süper lig|1\. lig|2\. lig|3\. lig|tff|uefa|fifa|şampiyonlar ligi|avrupa ligi|konferans ligi|milli takım|a milli|trabzonspor|galatasaray|fenerbahçe|beşiktaş|başakşehir|samsunspor|göztepe|kasımpaşa|rizespor|alanyaspor|kayserispor|konyaspor|antalyaspor|gaziantep fk|eyüpspor|gençlerbirliği|çorum fk|amed|boluspor|erzurumspor|sakaryaspor|bandırmaspor|ümraniyespor|manisaspor|premier league|la liga|bundesliga|serie a|ligue 1|champions league|europa league|world cup|transfer|teknik direktör|hakem|golcü|forvet|kaleci|defans|orta saha)/i;
const newsCache = { items: [], refreshedAt: null, sourceStatus: [] };
const leaguesCache = { items: [], refreshedAt: null };
const dataCache = new Map();
const inFlight = new Map();
const providerStatus = new Map();

const json = (res, data, maxAge = 30) => res.set("Cache-Control", `public, max-age=${maxAge}`).json(data);
const validSeason = value => /^20\d{2}$/.test(String(value || "")) && Number(value) >= 2000 && Number(value) <= CURRENT_SEASON + 2;
const validShortcut = value => /^[a-z0-9._-]{2,30}$/i.test(String(value || ""));
const cacheGet = key => { const v = dataCache.get(key); return v ? v.data : null; };
const cacheFresh = (key, ttl = DATA_REFRESH_MS) => { const v = dataCache.get(key); return !!v && Date.now() - v.time < ttl; };
const cacheSet = (key, data) => { dataCache.set(key, { data, time: Date.now() }); if (dataCache.size > 300) dataCache.delete(dataCache.keys().next().value); return data; };

async function requestJSON(url, headers = {}) {
  const response = await fetch(url, { headers: { Accept: "application/json", "User-Agent": `DOKSAN/${VERSION}`, ...headers }, signal: AbortSignal.timeout(15000) });
  if (!response.ok) throw new Error(`Upstream ${response.status}`);
  return response.json();
}
async function cachedRequest(key, url, headers = {}, ttl = DATA_REFRESH_MS) {
  if (cacheFresh(key, ttl)) return cacheGet(key);
  if (inFlight.has(key)) return inFlight.get(key);
  const providerName=key.split(":")[0];
  const task = requestJSON(url, headers).then(data => {
    providerStatus.set(providerName,{ok:true,checkedAt:new Date().toISOString()});
    return cacheSet(key, data);
  }).catch(error => {
    providerStatus.set(providerName,{ok:false,checkedAt:new Date().toISOString(),error:String(error.message||"API error").slice(0,120)});
    const stale = cacheGet(key);
    if (stale) return stale;
    throw error;
  }).finally(() => inFlight.delete(key));
  inFlight.set(key, task);
  return task;
}

async function refreshNews() {
  const statuses = [];
  const all = [];
  await Promise.all(sourceList.map(async source => {
    try {
      const feed = await parser.parseURL(source.url);
      const items = (feed.items || []).slice(0, 40).map(item => {
        const title = cleanText(item.title);
        const url = item.link || item.guid;
        const published = new Date(item.isoDate || item.pubDate || "");
        const description = cleanText(item.contentSnippet || item.summary || item.content).slice(0, 320);
        const rawHtml = String(item["content:encoded"] || item.content || item.summary || "");
        const media = item.enclosure?.url || item["media:content"]?.url || item["media:thumbnail"]?.url || item.itunes?.image || null;
        const htmlImage = rawHtml.match(/<img[^>]+src=["']([^"']+)["']/i)?.[1] || rawHtml.match(/<img[^>]+src=([^\s>]+)/i)?.[1] || null;
        const image = [media, htmlImage].find(v => typeof v === "string" && /^https?:\/\//i.test(v)) || null;
        if (!title || !/^https?:\/\//i.test(url || "") || !Number.isFinite(published.getTime()) || !FOOTBALL.test(`${title} ${description}`)) return null;
        return { id: normalizeText(title), title, description, image, url, source: source.name, region: source.region, publishedAt: published.toISOString(), category: TRANSFER.test(`${title} ${description}`) ? "transfer" : BREAKING.test(`${title} ${description}`) ? "breaking" : "news",
          transferStatus: TRANSFER.test(`${title} ${description}`) ? (/(resmi|resmen|duyurdu|imza attı|signed|officially announced|official announcement)/i.test(`${title} ${description}`) ? "official" : "rumor") : null };
      }).filter(Boolean);
      all.push(...items);
      statuses.push({ source: source.name, ok: true, count: items.length });
    } catch (error) {
      statuses.push({ source: source.name, ok: false, count: 0, error: String(error.message || "Feed error").slice(0, 100) });
    }
  }));
  const freshItems = dedupeNews(all).slice(0, 400);
  // Do not erase a good snapshot if every feed temporarily fails.
  if (freshItems.length || !newsCache.items.length) {
    newsCache.items = freshItems;
    newsCache.refreshedAt = new Date().toISOString();
  }
  newsCache.sourceStatus = statuses;
}

async function refreshLeagues() {
  try {
    const data = await cachedRequest(`openliga:leagues:${CURRENT_SEASON}`, `${OPENLIGA}/getavailableleagues/${CURRENT_SEASON}`, {}, 30 * 60 * 1000);
    if (!Array.isArray(data)) throw new Error("Invalid leagues payload");
    const seen = new Set();
    const items = data.filter(x => x?.leagueShortcut && Number(x.leagueSeason) === CURRENT_SEASON)
      .filter(x => /fußball|football|soccer/i.test(x.sport?.sportName || "Fußball"))
      .filter(x => { const key = `${x.leagueShortcut}:${x.leagueSeason}`; if (seen.has(key)) return false; seen.add(key); return true; })
      .map(x => ({ id: x.leagueId, name: cleanText(x.leagueName), shortcut: x.leagueShortcut, season: Number(x.leagueSeason), country: cleanText(x.league?.country || "") }))
      .sort((a,b) => a.name.localeCompare(b.name, "tr"));
    leaguesCache.items = items;
    leaguesCache.refreshedAt = new Date().toISOString();
  } catch { /* retain last good data */ }
}

async function getOpenLigaMatches(shortcut, season) {
  const key = `openliga:matches:${shortcut}:${season}`;
  const data = await cachedRequest(key, `${OPENLIGA}/getmatchdata/${encodeURIComponent(shortcut)}/${season}`);
  if (!Array.isArray(data)) throw new Error("Invalid match payload");
  return data.filter(m => m?.team1?.teamName && m?.team2?.teamName && Number.isFinite(Date.parse(m.matchDateTimeUTC || m.matchDateTime)));
}
async function getOpenLigaTable(shortcut, season) {
  const key = `openliga:table:${shortcut}:${season}`;
  const data = await cachedRequest(key, `${OPENLIGA}/getbltable/${encodeURIComponent(shortcut)}/${season}`);
  if (!isValidStandingTable(data)) throw new Error("Standings consistency check failed");
  return data;
}
function fdHeaders() {
  if (!process.env.FOOTBALL_DATA_TOKEN) throw new Error("FOOTBALL_DATA_TOKEN is not configured");
  return { "X-Auth-Token": process.env.FOOTBALL_DATA_TOKEN };
}
function mapFDMatch(m) {
  const full = m.score?.fullTime || {};
  const half = m.score?.halfTime || {};
  const finished = ["FINISHED", "AWARDED"].includes(m.status);
  const hasScore = Number.isInteger(full.home) && Number.isInteger(full.away);
  return {
    id: m.id, date: m.utcDate, home: m.homeTeam?.name || "", away: m.awayTeam?.name || "",
    homeId: m.homeTeam?.id || null, awayId: m.awayTeam?.id || null,
    homeLogo: m.homeTeam?.crest || null, awayLogo: m.awayTeam?.crest || null,
    status: finished && hasScore ? "finished" : ["IN_PLAY", "PAUSED", "LIVE", "EXTRA_TIME", "PENALTY_SHOOTOUT"].includes(m.status) ? "live" : "scheduled",
    score: hasScore ? { home: full.home, away: full.away, resultType: m.status } : null,
    halftime: Number.isInteger(half.home) && Number.isInteger(half.away) ? { home: half.home, away: half.away } : null,
    minute: m.minute || null, matchday: m.matchday || null, venue: m.venue || null, source: "football-data.org"
  };
}
async function getFDMatches(code, season) {
  const key = `fd:matches:${code}:${season}`;
  const data = await cachedRequest(key, `${FOOTBALL_DATA}/competitions/${encodeURIComponent(code)}/matches?season=${season}`, fdHeaders());
  if (!Array.isArray(data.matches)) throw new Error("Invalid football-data match payload");
  return data.matches.map(mapFDMatch);
}
async function getFDTable(code, season) {
  const key = `fd:table:${code}:${season}`;
  const data = await cachedRequest(key, `${FOOTBALL_DATA}/competitions/${encodeURIComponent(code)}/standings?season=${season}`, fdHeaders());
  const table = data.standings?.find(x => x.type === "TOTAL")?.table || data.standings?.[0]?.table || [];
  const rows = table.map(x => ({ position: x.position, teamName: x.team?.name || "", matches: x.playedGames, won: x.won, draw: x.draw, lost: x.lost, points: x.points, goals: x.goalsFor, opponentGoals: x.goalsAgainst, goalDiff: x.goalDifference, teamId: x.team?.id, crest: x.team?.crest }));
  if (!isValidStandingTable(rows)) throw new Error("football-data standings validation failed");
  return rows;
}


function dateKey(d) { return `${d.getUTCFullYear()}${String(d.getUTCMonth()+1).padStart(2,"0")}${String(d.getUTCDate()).padStart(2,"0")}`; }
function mapESPNEvent(event, leagueName) {
  const comp=event.competitions?.[0], sides=comp?.competitors||[];
  const home=sides.find(x=>x.homeAway==="home"), away=sides.find(x=>x.homeAway==="away");
  if(!home||!away) return null;
  const state=comp?.status?.type?.state||event.status?.type?.state||"pre";
  const hs=home.score!==undefined&&home.score!==null&&home.score!==""?Number(home.score):null;
  const as=away.score!==undefined&&away.score!==null&&away.score!==""?Number(away.score):null;
  const has=Number.isInteger(hs)&&Number.isInteger(as);
  return {id:`espn-${event.id}`,date:event.date||comp?.date,home:home.team?.displayName||home.team?.name||"",away:away.team?.displayName||away.team?.name||"",homeId:Number(home.team?.id)||null,awayId:Number(away.team?.id)||null,homeLogo:home.team?.logo||null,awayLogo:away.team?.logo||null,status:state==="in"?"live":state==="post"&&has?"finished":"scheduled",score:has?{home:hs,away:as}:null,minute:comp?.status?.displayClock||comp?.status?.type?.shortDetail||null,competition:leagueName||"",source:"ESPN",sourceUrl:event.links?.find(x=>x.rel?.includes("summary"))?.href||null,venue:comp?.venue?.fullName||null,events:(comp?.details||[]).slice(-6).map(d=>({type:d.type?.text||"Olay",clock:d.clock?.displayValue||"",detail:d.athletesInvolved?.[0]?.displayName||""}))};
}
async function getESPNScoreboard(code, from, to) {
  const key=`espn:score:${code}:${from}:${to}`;
  const data=await cachedRequest(key,`https://site.api.espn.com/apis/site/v2/sports/soccer/${encodeURIComponent(code)}/scoreboard?dates=${from}-${to}&limit=500`,{},90_000);
  if(!Array.isArray(data.events)) throw new Error("Invalid ESPN scoreboard");
  const name=ESPN_COMPETITIONS.find(x=>x[0]===code)?.[1]||"";
  return data.events.map(e=>mapESPNEvent(e,name)).filter(Boolean);
}
function mapSportScore(m) {
  const home=cleanText(m.home?.name||(typeof m.home==="string"?m.home:"")||m.homeTeam?.name||m.home_team?.name||m.home_team||m.strHomeTeam||m.team_home||"");
  const away=cleanText(m.away?.name||(typeof m.away==="string"?m.away:"")||m.awayTeam?.name||m.away_team?.name||m.away_team||m.strAwayTeam||m.team_away||"");
  if(!home||!away) return null;
  const raw=String(m.status?.type?.state||m.status?.short||m.status||m.state||m.status_text||m.statusText||"").toLowerCase();
  const hs=Number(m.home_score??m.homeScore??m.score?.home??m.goals?.home??m.intHomeScore);
  const as=Number(m.away_score??m.awayScore??m.score?.away??m.goals?.away??m.intAwayScore);
  const has=Number.isInteger(hs)&&Number.isInteger(as);
  const live=/live|in.?play|in.?progress|playing|1h|2h|half|extra|penalty|ht/.test(raw);
  const finished=/finish|full.time|ft|ended|complete/.test(raw);
  const rawDate=m.time||m.date||m.kickoff||m.start_time||m.strTimestamp||m.timestamp||m.startTimestamp||new Date().toISOString();
  const numericDate=typeof rawDate==="number"?rawDate:/^\d{10,13}$/.test(String(rawDate))?Number(rawDate):null;
  const parsedDate=numericDate!==null?(numericDate>1e12?new Date(numericDate).toISOString():new Date(numericDate*1000).toISOString()):String(rawDate);
  return {id:`sportscore-${m.id||m.fixture_id||m.slug||home+away}`,date:parsedDate,home,away,homeId:m.home?.id||null,awayId:m.away?.id||null,homeLogo:m.home_logo||m.home?.logo||null,awayLogo:m.away_logo||m.away?.logo||null,status:live?"live":finished&&has?"finished":"scheduled",score:has?{home:hs,away:as}:null,minute:m.minute||m.time_elapsed||m.status_text||m.statusText||null,competition:m.competition?.name||m.competition_name||m.league||"",source:"SportScore",sourceUrl:m.url||null};
}
async function getESPNLive() {
  const from=dateKey(new Date(Date.now()-86400000)),to=dateKey(new Date(Date.now()+86400000));
  const results=await Promise.allSettled(ESPN_COMPETITIONS.slice(0,9).map(c=>getESPNScoreboard(c[0],from,to)));
  if(results.every(x=>x.status==="rejected"))throw new Error("All ESPN league endpoints failed");return results.flatMap(x=>x.status==="fulfilled"?x.value.filter(m=>m.status==="live"):[]);
}
async function getSportScoreWidgetLive() {
  const data=await cachedRequest("sportscore:widget-live",`${SPORTScore}/api/widget/matches/?sport=football&limit=50`,{},60_000);
  const list=Array.isArray(data)?data:(data.matches||data.fixtures||data.data?.matches||data.data?.fixtures||data.data||data.items||[]);
  return list.map(mapSportScore).filter(x=>x&&x.status==="live");
}
async function getFootballDataLive() {
  if(!process.env.FOOTBALL_DATA_TOKEN) return [];
  const data=await cachedRequest("fd:live:all",`${FOOTBALL_DATA}/matches?status=IN_PLAY`,{ "X-Auth-Token":process.env.FOOTBALL_DATA_TOKEN },60_000);
  if(!Array.isArray(data.matches)) throw new Error("Invalid football-data live payload");
  return data.matches.map(mapFDMatch).filter(x=>x.status==="live");
}
async function aggregateLive() {
  const results=await Promise.allSettled([getESPNLive(),getSportScoreWidgetLive(),getFootballDataLive()]);
  const labels=["ESPN","SportScore","football-data.org"];
  const sources=results.map((r,i)=>({source:labels[i],configured:i!==2||Boolean(process.env.FOOTBALL_DATA_TOKEN),ok:r.status==="fulfilled"&&(i!==2||Boolean(process.env.FOOTBALL_DATA_TOKEN)),count:r.status==="fulfilled"?r.value.length:0,error:r.status==="rejected"?String(r.reason?.message||"API error").slice(0,100):null}));
  const matches=results.flatMap(r=>r.status==="fulfilled"?r.value:[]);
  return {items:reconcileMatches(matches),sources,updatedAt:new Date().toISOString(),availableSources:sources.filter(x=>x.ok).length};
}

function leagueNameFor(provider, code) {
  if(provider==="espn") return ESPN_COMPETITIONS.find(x=>x[0]===code)?.[1]||"";
  if(provider==="football-data") return FD_COMPETITIONS.find(x=>x[0]===code)?.[1]||"";
  if(provider==="openfootball") return Object.entries(OPENFOOTBALL_MAP).find(([k,v])=>k===code||v===code)?.[1]||"";
  return leaguesCache.items.find(x=>x.shortcut===code)?.name||"";
}
function findOpenLigaLeague(provider, code) {
  const name=leagueNameFor(provider,code).toLocaleLowerCase("tr-TR");
  const aliases={"tur.1":[/s[uü]per\s*lig/i,/turkish\s*super/i],"eng.1":[/premier\s*league/i],"esp.1":[/la\s*liga/i],"ger.1":[/bundesliga/i],"ita.1":[/serie\s*a/i],"fra.1":[/ligue\s*1/i],"uefa.champions":[/champions\s*league/i],"uefa.europa":[/europa\s*league/i],"ned.1":[/eredivisie/i],"por.1":[/primeira\s*liga/i]};
  const regexes=aliases[code]||[];
  return leaguesCache.items.find(x=>regexes.some(r=>r.test(x.name)))?.shortcut || leaguesCache.items.find(x=>name && x.name.toLocaleLowerCase("tr-TR").includes(name))?.shortcut || null;
}
function findESPNLeague(provider, code) {
  const name=leagueNameFor(provider,code).toLocaleLowerCase("tr-TR");
  const aliases={pl:"eng.1",pd:"esp.1",bl1:"ger.1",sa:"ita.1",fl1:"fra.1",ded:"ned.1",ppl:"por.1",cl:"uefa.champions",turkish:"tur.1",tsl:"tur.1",sl1:"tur.1"};
  if(aliases[code.toLowerCase()]) return aliases[code.toLowerCase()];
  const direct=ESPN_COMPETITIONS.find(x=>x[1].toLocaleLowerCase("tr-TR")===name);
  if(direct) return direct[0];
  const tests=[["premier league","eng.1"],["la liga","esp.1"],["bundesliga","ger.1"],["serie a","ita.1"],["ligue 1","fra.1"],["champions league","uefa.champions"],["europa league","uefa.europa"],["super lig","tur.1"],["süper lig","tur.1"]];
  return tests.find(([part])=>name.includes(part))?.[1]||null;
}
async function getOpenFootballMatches(code,season) {
  const leagueCode=OPENFOOTBALL_MAP[code]||code;
  if(!Object.values(OPENFOOTBALL_MAP).includes(leagueCode))throw new Error("OpenFootball does not cover this league");
  const start=Number(season),end=String(start+1).slice(-2),folder=`${start}-${end}`;
  const data=await cachedRequest(`openfootball:${leagueCode}:${folder}`,
    `https://raw.githubusercontent.com/openfootball/football.json/master/${folder}/${leagueCode}.json`,{},6*60*60*1000);
  if(!Array.isArray(data.matches))throw new Error("Invalid OpenFootball fixture payload");
  return data.matches.map(m=>mapOpenFootballMatch(m,leagueCode)).filter(Boolean);
}
async function fetchFixturesFrom(provider,code,season) {
  let rows;
  if(provider==="espn") { const from=dateKey(new Date(Date.now()-7*86400000)),to=dateKey(new Date(Date.now()+35*86400000)); rows=await getESPNScoreboard(code,from,to); }
  else if(provider==="football-data") rows=await getFDMatches(code,season);
  else if(provider==="openfootball") rows=await getOpenFootballMatches(code,season);
  else rows=(await getOpenLigaMatches(code,season)).map(mapOpenLigaMatch);
  if(!rows.length)throw new Error("No fixture rows from provider");
  return rows;
}
async function fetchTableFrom(provider,code,season) {
  if(provider==="espn") return await getESPNTable(code);
  if(provider==="football-data") return await getFDTable(code,season);
  return await getOpenLigaTable(code,season);
}
function fallbackCandidates(provider,code) {
  const out=[];
  if(provider!=="espn") { const espn=findESPNLeague(provider,code); if(espn) out.push(["espn",espn]); }
  if(provider!=="openligadb") { const open=findOpenLigaLeague(provider,code); if(open) out.push(["openligadb",open]); }
  if(provider!=="football-data"&&process.env.FOOTBALL_DATA_TOKEN) {
    const name=leagueNameFor(provider,code).toLowerCase(); const fd=FD_COMPETITIONS.find(x=>name.includes(x[1].toLowerCase())||x[1].toLowerCase().includes(name)); if(fd) out.push(["football-data",fd[0]]);
  }
  const openfootball=OPENFOOTBALL_MAP[code]||null;
  if(provider!=="openfootball"&&openfootball) out.push(["openfootball",openfootball]);
  return out.filter((x,i,a)=>a.findIndex(y=>y[0]===x[0]&&y[1]===x[1])===i);
}

async function getESPNTable(code) {
  const data=await cachedRequest(`espn:table:${code}`,`https://site.api.espn.com/apis/v2/sports/soccer/${encodeURIComponent(code)}/standings`,{},5*60_000);
  const rows=[];
  const number=(stats,names)=>{const x=stats.find(v=>names.includes(v.name)||names.includes(v.abbreviation));if(!x)return null;const n=Number(x.value??x.displayValue);return Number.isFinite(n)?n:null;};
  const walk=node=>{if(!node||typeof node!=="object")return;if(Array.isArray(node.entries))for(const e of node.entries){const st=e.stats||[],t=e.team||{};const row={position:number(st,["rank","playoffSeed"])||rows.length+1,teamName:t.displayName||t.name||"",matches:number(st,["gamesPlayed","GP"]),won:number(st,["wins","W"]),draw:number(st,["ties","draws","D"]),lost:number(st,["losses","L"]),points:number(st,["points","PTS"]),goals:number(st,["pointsFor","goalsFor","GF"]),opponentGoals:number(st,["pointsAgainst","goalsAgainst","GA"]),goalDiff:number(st,["pointDifferential","goalDifference","GD"]),teamId:Number(t.id)||null,crest:t.logo||null};if(row.teamName&&row.matches!==null&&row.points!==null)rows.push(row);}for(const c of node.children||[])walk(c);if(node.standings&&node.standings!==node)walk(node.standings);};
  walk(data);if(!rows.length||rows.some(r=>[r.matches,r.won,r.draw,r.lost,r.points,r.goals,r.opponentGoals,r.goalDiff].some(v=>!Number.isInteger(v))))throw new Error("ESPN standings incomplete");return rows;
}


app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  next();
});
app.get("/robots.txt",(req,res)=>res.type("text/plain").send("User-agent: *\\nAllow: /\\nDisallow: /api/\\nSitemap: /sitemap.xml\\n"));
app.get("/sitemap.xml",(req,res)=>res.type("application/xml").send(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${req.protocol}://${req.get("host")}/</loc><changefreq>hourly</changefreq><priority>1.0</priority></url></urlset>`));
app.use(express.static(path.join(__dirname, "public"), { maxAge: "1h", etag: true }));

app.get("/api/health", (req,res) => json(res, {
  ok: true, app: "DOKSAN", version: VERSION,
  newsUpdatedAt: newsCache.refreshedAt, newsSourcesAvailable: newsCache.sourceStatus.filter(x => x.ok).length,
  newsSourcesTotal: sourceList.length, openLigaUpdatedAt: leaguesCache.refreshedAt,
  optionalFootballDataConfigured: Boolean(process.env.FOOTBALL_DATA_TOKEN),
  liveProviders: ["ESPN","SportScore",...(process.env.FOOTBALL_DATA_TOKEN?["football-data.org"]:[])],
  fixtureBackupProvider: "OpenFootball",
  supplementaryTeamProvider: "TheSportsDB",
  providerStatus: Object.fromEntries(providerStatus)
}, 10));

app.get("/api/news", (req,res) => {
  const region = String(req.query.region || "all");
  const category = String(req.query.category || "all");
  const q = normalizeText(req.query.q || "");
  let items = newsCache.items;
  if (["turkey", "world"].includes(region)) items = items.filter(x => x.region === region);
  if (category === "transfer") items = items.filter(x => x.category === "transfer");
  if (category === "breaking") items = items.filter(x => x.category === "breaking");
  if (category === "news") items = items.filter(x => x.category !== "transfer");
  if (q) items = items.filter(x => normalizeText(`${x.title} ${x.description} ${x.source}`).includes(q));
  json(res, { items: items.slice(0, 250), updatedAt: newsCache.refreshedAt, sourceCount: newsCache.sourceStatus.filter(x => x.ok).length, totalSources: sourceList.length });
});

app.get("/api/transfers", (req,res) => {
  const q = normalizeText(req.query.q || "");
  const items = newsCache.items.filter(x => x.category === "transfer" && (!q || normalizeText(`${x.title} ${x.description} ${x.source}`).includes(q)));
  json(res,{items:items.slice(0,150),updatedAt:newsCache.refreshedAt,sourceCount:newsCache.sourceStatus.filter(x=>x.ok).length,totalSources:sourceList.length});
});

app.get("/api/competitions", async (req,res) => {
  const provider=String(req.query.provider||"all");let items=provider==="espn"?[]:leaguesCache.items;
  if(provider==="all"||provider==="espn")items=[...ESPN_COMPETITIONS.map(([shortcut,name,country])=>({id:`espn-${shortcut}`,name,shortcut,season:CURRENT_SEASON,country,provider:"espn"})),...items];
  if(process.env.FOOTBALL_DATA_TOKEN&&(provider==="all"||provider==="football-data"))items=[...items,...FD_COMPETITIONS.map(([shortcut,name,country])=>({id:`fd-${shortcut}`,name,shortcut,season:CURRENT_SEASON,country,provider:"football-data"}))];
  const seen=new Set();items=items.filter(x=>{const k=`${x.provider}:${x.shortcut}`;if(seen.has(k))return false;seen.add(k);return true;});
  json(res,{items,updatedAt:leaguesCache.refreshedAt,providers:["ESPN","SportScore","OpenLigaDB","OpenFootball (fikstür yedeği)","TheSportsDB (takım bilgileri)",...(process.env.FOOTBALL_DATA_TOKEN?["football-data.org"]:[])]});
});
app.get("/api/live",async(req,res)=>{
  try{const cached=cacheGet("live:aggregate");if(cached&&Date.now()-dataCache.get("live:aggregate").time<35_000)return json(res,cached,10);if(inFlight.has("live:aggregate"))return json(res,await inFlight.get("live:aggregate"),10);const task=aggregateLive().then(d=>cacheSet("live:aggregate",d)).finally(()=>inFlight.delete("live:aggregate"));inFlight.set("live:aggregate",task);json(res,await task,10);}catch{res.status(502).json({error:"Canlı skor kaynaklarına şu anda ulaşılamıyor.",items:[],sources:[]});}
});

app.get("/api/fixtures", async (req,res) => {
  const league = String(req.query.league || "");
  const season = Number(req.query.season || CURRENT_SEASON);
  const provider = String(req.query.provider || "openligadb");
  if (!league || !validSeason(season)) return res.status(400).json({ error: "Geçerli league ve season parametreleri gerekli." });
  if(!["espn","football-data","openligadb"].includes(provider))return res.status(400).json({error:"Bilinmeyen veri sağlayıcısı."});
  try {
    const attempts=[[provider,league],...fallbackCandidates(provider,league)]; let items=null,used=null,failures=[];
    for(const [candidate,code] of attempts){try{items=await fetchFixturesFrom(candidate,code,season);used=candidate;break;}catch(e){failures.push(`${candidate}:${String(e.message||"error").slice(0,60)}`);}}
    if(!items)throw new Error("All fixture sources failed");
    items.sort((a,b)=>Date.parse(a.date)-Date.parse(b.date));
    json(res,{items,updatedAt:new Date().toISOString(),provider:used==="football-data"?"football-data.org":used==="espn"?"ESPN":used==="openfootball"?"OpenFootball":"OpenLigaDB",requestedProvider:provider,fallbackUsed:used!==provider,failedSources:failures});
  }catch{res.status(502).json({error:"Maç verisi hiçbir uygun kaynaktan doğrulanamadı; yanlış veri gösterilmiyor."});}
});

app.get("/api/standings", async (req,res) => {
  const league=String(req.query.league||""),season=Number(req.query.season||CURRENT_SEASON),provider=String(req.query.provider||"openligadb");
  if(!league||!validSeason(season))return res.status(400).json({error:"Geçerli lig ve sezon gerekli."});
  if(!["espn","football-data","openligadb"].includes(provider))return res.status(400).json({error:"Bilinmeyen veri sağlayıcısı."});
  try{
    const attempts=[[provider,league],...fallbackCandidates(provider,league)];let items=null,used=null,failures=[];
    for(const [candidate,code] of attempts){try{items=await fetchTableFrom(candidate,code,season);used=candidate;break;}catch(e){failures.push(`${candidate}:${String(e.message||"error").slice(0,60)}`);}}
    if(!items)throw new Error("All standings sources failed");
    json(res,{items,updatedAt:new Date().toISOString(),provider:used==="football-data"?"football-data.org":used==="espn"?"ESPN":used==="openfootball"?"OpenFootball":"OpenLigaDB",requestedProvider:provider,fallbackUsed:used!==provider,failedSources:failures});
  }catch{res.status(502).json({error:"Puan tablosu hiçbir uygun kaynaktan doğrulanamadı; hatalı tablo gösterilmiyor."});}
});

app.get("/api/league/:provider/:code", async (req,res) => {
  const provider=String(req.params.provider||""),code=String(req.params.code||""),season=Number(req.query.season||CURRENT_SEASON);
  if(!["espn","football-data","openligadb"].includes(provider)||!validSeason(season)||!validShortcut(code))
    return res.status(400).json({error:"Geçersiz lig parametreleri."});
  const attempts=[[provider,code],...fallbackCandidates(provider,code)];
  let fixtures=null,table=null,fixtureSource=null,tableSource=null;
  for(const [p,c] of attempts){
    if(!fixtures) try{fixtures=await fetchFixturesFrom(p,c,season);fixtureSource=p;}catch{}
    if(!table) try{table=await fetchTableFrom(p,c,season);tableSource=p;}catch{}
    if(fixtures&&table)break;
  }
  if(!fixtures&&!table)return res.status(502).json({error:"Lig verisi hiçbir kaynaktan doğrulanamadı."});
  const teams=new Map();
  for(const m of fixtures||[]){if(m.homeId)teams.set(String(m.homeId),{id:m.homeId,name:m.home,logo:m.homeLogo});if(m.awayId)teams.set(String(m.awayId),{id:m.awayId,name:m.away,logo:m.awayLogo});}
  json(res,{name:leagueNameFor(provider,code)||code,season,fixtures:fixtures||[],standings:table||[],teams:[...teams.values()],
    sources:{fixtures:fixtureSource,standings:tableSource},updatedAt:new Date().toISOString()});
});

app.get("/api/teams/:id", async (req,res) => {
  const teamId = Number(req.params.id);
  const provider = String(req.query.provider || "openligadb");
  const teamLeague = String(req.query.league || "tur.1");
  if (!Number.isInteger(teamId) || teamId <= 0 || (provider === "espn" && !validShortcut(teamLeague))) return res.status(400).json({ error: "Geçersiz takım veya lig kimliği." });
  try {
    if (provider === "espn") {
      const team=await cachedRequest(`espn:team-detail:${teamId}`,`https://site.api.espn.com/apis/site/v2/sports/soccer/${encodeURIComponent(teamLeague)}/teams/${teamId}`,{},30*60*1000);
      const schedule=await cachedRequest(`espn:team-schedule:${teamId}`,`https://site.api.espn.com/apis/site/v2/sports/soccer/${encodeURIComponent(teamLeague)}/teams/${teamId}/schedule`,{},2*60*1000);
      const matches=(schedule.events||[]).map(e=>{const c=e.competitions?.[0],sides=c?.competitors||[],h=sides.find(x=>x.homeAway==="home"),a=sides.find(x=>x.homeAway==="away");if(!h||!a)return null;const st=c?.status?.type?.state||"pre",hs=Number(h.score),as=Number(a.score),has=Number.isInteger(hs)&&Number.isInteger(as);return{id:`espn-${e.id}`,date:e.date,home:h.team?.displayName||h.team?.name,away:a.team?.displayName||a.team?.name,homeLogo:h.team?.logo,awayLogo:a.team?.logo,status:st==="in"?"live":st==="post"&&has?"finished":"scheduled",score:has?{home:hs,away:as}:null,minute:c?.status?.displayClock,source:"ESPN"};}).filter(Boolean);
      return json(res,{team:{id:teamId,name:team.team?.displayName||team.team?.name||team.displayName||"Takım",logo:team.team?.logos?.[0]?.href||null},matches,provider:"ESPN"});
    }
    if (provider === "football-data") {
      const [team, payload] = await Promise.all([
        cachedRequest(`fd:team:${teamId}`, `${FOOTBALL_DATA}/teams/${teamId}`, fdHeaders(), 30 * 60 * 1000),
        cachedRequest(`fd:team-matches:${teamId}`, `${FOOTBALL_DATA}/teams/${teamId}/matches?limit=20`, fdHeaders())
      ]);
      if (!Array.isArray(payload.matches)) throw new Error("Invalid team match payload");
      json(res, { team: { id: team.id, name: team.name, logo: team.crest || null }, matches: payload.matches.map(mapFDMatch).sort((a,b) => Date.parse(a.date)-Date.parse(b.date)), updatedAt: new Date().toISOString(), provider: "football-data.org" });
      return;
    }
    const key = `openliga:team:${teamId}`;
    const data = await cachedRequest(key, `${OPENLIGA}/getmatchesbyteamid/${teamId}/5/5`);
    if (!Array.isArray(data) || !data.length) return res.status(404).json({ error: "Bu takım için maç verisi bulunamadı." });
    const sample = data.find(m => m.team1?.teamId === teamId || m.team2?.teamId === teamId);
    if (!sample) return res.status(404).json({ error: "Takım verisi bulunamadı." });
    const isHome = sample.team1.teamId === teamId;
    json(res, { team: { id: teamId, name: isHome ? sample.team1.teamName : sample.team2.teamName, logo: isHome ? sample.team1.teamIconUrl : sample.team2.teamIconUrl }, matches: data.map(mapOpenLigaMatch).sort((a,b) => Date.parse(a.date)-Date.parse(b.date)), updatedAt: new Date().toISOString(), provider: "OpenLigaDB" });
  } catch { res.status(502).json({ error: "Takım verisi şu anda doğrulanamadı." }); }
});

// TheSportsDB free v1 is used only for supplementary team profile data; its free tier does not include livescores.
app.get("/api/team-profile", async (req,res) => {
  const name = cleanText(req.query.name || "").slice(0,80);
  if (name.length < 2) return res.status(400).json({error:"Takım adı gerekli."});
  try {
    const searchKey = normalizeText(name);
    const payload = await cachedRequest(`tsdb:team-search:${searchKey}`,
      `https://www.thesportsdb.com/api/v1/json/123/searchteams.php?t=${encodeURIComponent(name)}`,{},24*60*60*1000);
    const found = (payload.teams || []).find(t => /soccer/i.test(t.strSport || "") &&
      (normalizeText(t.strTeam)===searchKey || searchKey.includes(normalizeText(t.strTeam)) || normalizeText(t.strTeam).includes(searchKey)));
    if (!found) return res.status(404).json({error:"TheSportsDB takım profili bulunamadı."});
    const rosterPayload = await cachedRequest(`tsdb:players:${found.idTeam}`,
      `https://www.thesportsdb.com/api/v1/json/123/lookup_all_players.php?id=${encodeURIComponent(found.idTeam)}`,{},12*60*60*1000).catch(()=>({player:[]}));
    const players = (rosterPayload.player || []).filter(p=>p.strPlayer).slice(0,30).map(p=>({
      id:p.idPlayer,name:p.strPlayer,position:p.strPosition||null,nationality:p.strNationality||null,
      number:p.strNumber||null,photo:p.strCutout||p.strThumb||null
    }));
    json(res,{team:{id:found.idTeam,name:found.strTeam,badge:found.strBadge||null,stadium:found.strStadium||null,
      location:found.strLocation||null,formed:found.intFormedYear||null,manager:found.strManager||null,
      website:found.strWebsite||null,description:cleanText(found.strDescriptionEN||"").slice(0,900)},
      players,provider:"TheSportsDB",attribution:"TheSportsDB"},30*60);
  } catch { res.status(502).json({error:"Ek takım profili şu anda alınamıyor."}); }
});

app.get("/api/admin/source-health", (req,res) => {
  if (!process.env.ADMIN_TOKEN || req.get("authorization") !== `Bearer ${process.env.ADMIN_TOKEN}`) return res.sendStatus(404);
  json(res, { newsSources: newsCache.sourceStatus, providers: Object.fromEntries(providerStatus), newsUpdatedAt: newsCache.refreshedAt, leaguesUpdatedAt: leaguesCache.refreshedAt }, 0);
});

await Promise.allSettled([refreshNews(), refreshLeagues()]);
setInterval(() => refreshNews().catch(() => {}), NEWS_REFRESH_MS).unref();
setInterval(() => refreshLeagues().catch(() => {}), 30 * 60 * 1000).unref();
app.listen(PORT, "0.0.0.0", () => console.log(`DOKSAN ${VERSION} listening on ${PORT}`));
