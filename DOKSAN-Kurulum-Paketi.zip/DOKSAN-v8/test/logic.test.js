import test from "node:test";
import assert from "node:assert/strict";
import { isValidStanding, isValidStandingTable, finalResult, mapOpenLigaMatch, mapOpenFootballMatch, dedupeNews, normalizeText, reconcileMatches } from "../lib/logic.js";

test("puan tablosu aritmetik tutarlılığını doğrular", () => {
  const good = { matches: 10, won: 6, draw: 2, lost: 2, points: 20, goals: 18, opponentGoals: 9, goalDiff: 9 };
  assert.equal(isValidStanding(good), true);
  assert.equal(isValidStandingTable([good]), true);
  assert.equal(isValidStanding({ ...good, points: 19 }), false);
  assert.equal(isValidStanding({ ...good, goalDiff: -2, goals: 8, opponentGoals: 10 }), true);
  assert.equal(isValidStandingTable([]), false);
});

test("maç sonucunda penaltı/uzatma sonucunu önceliklendirir", () => {
  const match = { matchIsFinished: true, matchResults: [
    { resultTypeKind: "After90Minutes", pointsTeam1: 1, pointsTeam2: 1 },
    { resultTypeKind: "AfterExtraTime", pointsTeam1: 2, pointsTeam2: 2 },
    { resultTypeKind: "AfterPenalties", pointsTeam1: 5, pointsTeam2: 4 }
  ] };
  assert.equal(finalResult(match).pointsTeam1, 5);
});

test("bitmemiş ve saati geçmiş maçı canlı diye etiketlemez", () => {
  const mapped = mapOpenLigaMatch({ matchID: 1, matchDateTimeUTC: "2020-01-01T12:00:00Z", matchIsFinished: false,
    team1: { teamName: "A", teamId: 1 }, team2: { teamName: "B", teamId: 2 }, matchResults: [] }, Date.now());
  assert.equal(mapped.status, "unverified");
  assert.equal(mapped.score, null);
});

test("haberleri başlığa göre tekilleştirir ve Türkçe karakterleri normalize eder", () => {
  assert.equal(normalizeText("İstanbul'da Şampiyon!").includes("istanbul"), true);
  const rows = dedupeNews([{ title: "Transfer Haberi", publishedAt: "2026-01-01", url: "a" }, { title: "TRANSFER HABERİ", publishedAt: "2026-01-02", url: "b" }]);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].url, "b");
});


test("bağımsız kaynaklar aynı skoru verirse tek maçta birleştirir", () => {
  const rows = reconcileMatches([
    { id:"a", date:"2026-11-03T18:00:00Z", home:"Trabzonspor", away:"Galatasaray", status:"live", score:{home:1,away:0}, source:"ESPN" },
    { id:"b", date:"2026-11-03T18:01:00Z", home:"Galatasaray", away:"Trabzonspor", status:"live", score:{home:0,away:1}, source:"SportScore" }
  ]);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].status, "live");
  assert.deepEqual(rows[0].score, {home:1,away:0});
  assert.equal(rows[0].sourceCount, 2);
});

test("kaynaklar farklı skor bildirirse skor göstermez", () => {
  const rows = reconcileMatches([
    { id:"a", date:"2026-11-03T18:00:00Z", home:"Trabzonspor", away:"Galatasaray", status:"live", score:{home:1,away:0}, source:"ESPN" },
    { id:"b", date:"2026-11-03T18:01:00Z", home:"Trabzonspor", away:"Galatasaray", status:"live", score:{home:2,away:0}, source:"SportScore" }
  ]);
  assert.equal(rows[0].status, "disputed");
  assert.equal(rows[0].score, null);
});


test("kaynaklar canlı ve bitti durumunda anlaşmazsa canlı skor kesin gösterilmez", () => {
  const rows = reconcileMatches([
    { id:"a", date:"2026-11-03T18:00:00Z", home:"Trabzonspor", away:"Galatasaray", status:"live", score:{home:1,away:0}, source:"ESPN" },
    { id:"b", date:"2026-11-03T18:01:00Z", home:"Trabzonspor", away:"Galatasaray", status:"finished", score:{home:1,away:0}, source:"SportScore" }
  ]);
  assert.equal(rows[0].status, "disputed");
  assert.equal(rows[0].score, null);
});


test("yakın başlıklı aynı haberleri zaman penceresinde birleştirir", () => {
  const rows = dedupeNews([
    { title: "Trabzonspor yeni transferini resmen açıkladı", publishedAt: "2026-11-03T10:00:00Z", url: "a", source: "Kaynak A" },
    { title: "Trabzonspor yeni transferini resmen duyurdu", publishedAt: "2026-11-03T11:00:00Z", url: "b", source: "Kaynak B" }
  ]);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].sourceCount, 2);
});


test("OpenFootball fikstür yedeği tarih ve tamamlanmış skoru doğru eşler", () => {
  const row = mapOpenFootballMatch({
    date:"2026-11-01",round:"Matchday 10",team1:"Arsenal FC",team2:"Chelsea FC",
    score:{ft:[2,1],ht:[1,0]}
  },"en.1",Date.parse("2026-11-03T00:00:00Z"));
  assert.equal(row.status,"finished");
  assert.deepEqual(row.score,{home:2,away:1});
  assert.equal(row.dateOnly,true);
  assert.equal(row.source,"OpenFootball");
});
