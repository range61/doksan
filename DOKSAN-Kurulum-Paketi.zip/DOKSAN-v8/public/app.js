const $ = id => document.getElementById(id);
let region = "all", category = "all", allNews = [], competitions = [], activeProvider = "openligadb", activeLeague = "tur.1", notificationPrimed = false, previousLiveScores = new Map();
const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function api(url) { const r = await fetch(url, { headers: { Accept: "application/json" } }); if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); }
function drawNews() {
  const q = $("q").value.toLocaleLowerCase("tr-TR");
  const items = allNews.filter(x => (region === "all" || x.region === region) && (category === "all" || x.category === category) && (`${x.title} ${x.description} ${x.source}`).toLocaleLowerCase("tr-TR").includes(q));
  $("count").textContent = `${items.length} haber`;
  $("newslist").innerHTML = items.length ? items.map(x => `<article class="news"><div class="meta"><b>${esc((x.sources || [x.source]).join(" · "))}</b>${x.sourceCount > 1 ? ` · ${x.sourceCount} kaynak` : ""} · ${new Date(x.publishedAt).toLocaleString("tr-TR")}${x.category === "transfer" ? `<span class="tag">${x.transferStatus === "official" ? "RESMÎ İFADE" : "TRANSFER GÜNDEMİ"}</span>` : x.category === "breaking" ? '<span class="tag">SON DAKİKA</span>' : ""}</div><h3><a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">${esc(x.title)}</a></h3>${x.description ? `<p>${esc(x.description)}</p>` : ""}</article>`).join("") : '<div class="empty">Bu filtrede haber bulunamadı. Kaynaklar yenilendikçe akış güncellenir.</div>';
}
function liveMarkup(m) {
  const score = m.score ? `${m.score.home} - ${m.score.away}` : "—";
  const src = (m.sources || [m.source]).filter(Boolean).join(" · ");
  return `<div class="match"><div>${m.homeLogo ? `<img src="${esc(m.homeLogo)}" width="20" height="20" loading="lazy" alt="" style="object-fit:contain;vertical-align:middle;margin-right:5px">` : ""}${esc(m.home)}</div><div class="score">${score}</div><div class="away">${m.awayLogo ? `<img src="${esc(m.awayLogo)}" width="20" height="20" loading="lazy" alt="" style="object-fit:contain;vertical-align:middle;margin-right:5px">` : ""}${esc(m.away)}</div><div class="meta2"><span>${esc(m.competition || "Futbol")}</span><span>${statusLabel(m)}${m.minute ? ` · ${esc(m.minute)}` : ""}</span><span>${esc(src)}</span></div>${m.events?.length ? `<div class="footnote">${m.events.map(e => `${esc(e.clock)} ${esc(e.type)} ${esc(e.detail)}`).join(" · ")}</div>` : ""}</div>`;
}
async function loadLive() {
  try {
    const d = await api("/api/live");
    const items = d.items || [];
    const live = items.filter(x => x.status === "live" || x.status === "disputed");
    $("livelist").innerHTML = live.length ? live.map(liveMarkup).join("") : '<div class="empty">Şu anda doğrulanmış canlı maç bulunamadı.</div>';
    $("livefresh").textContent = d.updatedAt ? `Son kontrol ${new Date(d.updatedAt).toLocaleTimeString("tr-TR")}` : "Canlı veri bekleniyor";
    $("liveSources").innerHTML = (d.sources || []).map(x => `${esc(x.source)}: ${x.configured === false ? "anahtar yok" : x.ok ? `erişilebilir (${x.count})` : "geçici hata"}`).join(" · ");
    const current = new Map();
    for (const m of live) {
      const k = `${m.home}|${m.away}`;
      const v = m.score ? `${m.score.home}-${m.score.away}` : "?";
      current.set(k, v);
      if (notificationPrimed && m.status === "live" && m.score && previousLiveScores.has(k) && previousLiveScores.get(k) !== "?" && v !== "?" && previousLiveScores.get(k) !== v && "Notification" in window && Notification.permission === "granted") {
        const title = "DOKSAN · Skor değişikliği", options = { body: `${m.home} ${v} ${m.away}`, icon: "/icon.svg" };
        if (navigator.serviceWorker?.ready) navigator.serviceWorker.ready.then(reg => reg.showNotification(title, options)).catch(() => new Notification(title, options)); else new Notification(title, options);
      }
    }
    previousLiveScores = current; notificationPrimed = true;
  } catch {
    $("livelist").innerHTML = '<div class="empty">Canlı skor kaynaklarına geçici olarak ulaşılamadı. Diğer haber ve fikstür bölümleri çalışmaya devam eder.</div>';
    $("livefresh").textContent = "Kaynak bağlantısı bekleniyor";
  }
}
const notifyBtn = $("notifyBtn");
if (notifyBtn) notifyBtn.addEventListener("click", async () => {
  if (!("Notification" in window)) { notifyBtn.textContent = "Tarayıcı desteklemiyor"; return; }
  const permission = await Notification.requestPermission();
  notifyBtn.textContent = permission === "granted" ? "Bildirimler açık" : "Bildirim izni verilmedi";
});
async function loadNews() {
  try { const d = await api("/api/news"); allNews = d.items || []; drawNews(); $("fresh").textContent = d.updatedAt ? `Haber akışı ${new Date(d.updatedAt).toLocaleTimeString("tr-TR")} · ${d.sourceCount||0}/${d.totalSources||15} kaynak erişilebilir` : "Haber kaynağı bekleniyor"; }
  catch { $("newslist").innerHTML = '<div class="empty">Haber servisine şu anda ulaşılamadı.</div>'; }
}
function competitionLabel(x) { return `${x.name}${x.country ? ` · ${x.country}` : ""}`; }
function updatePageMeta(title,description) {
  document.title=title;
  const desc=document.querySelector('meta[name="description"]'); if(desc)desc.content=description;
  const ogTitle=document.querySelector('meta[property="og:title"]'); if(ogTitle)ogTitle.content=title;
  const ogDesc=document.querySelector('meta[property="og:description"]'); if(ogDesc)ogDesc.content=description;
  const ogUrl=document.querySelector('meta[property="og:url"]'); if(ogUrl)ogUrl.content=location.href;
  const canonical=document.querySelector('link[rel="canonical"]'); if(canonical)canonical.href=location.href;
}
async function loadCompetitions() {
  try {
    const previous = $("competition").value;
    const d = await api("/api/competitions"); competitions = d.items || [];
    const sel = $("competition");
    sel.innerHTML = competitions.length ? competitions.map(x => `<option value="${esc(x.shortcut)}" data-season="${x.season}" data-provider="${x.provider || "openligadb"}">${esc(competitionLabel(x))}</option>`).join("") : '<option value="">Kaynakta lig bulunamadı</option>';
    if (previous && [...sel.options].some(o => o.value === previous)) sel.value = previous;
    drawLeagueList();
    if (competitions.length) {
      const params=new URLSearchParams(location.search);
      const wanted=params.get("league"), wantedProvider=params.get("provider");
      const option=[...sel.options].find(o=>o.value===wanted&&(!wantedProvider||o.dataset.provider===wantedProvider));
      if(option)sel.value=option.value;
      await loadLeague();
      if(params.get("team")) await loadTeam(params.get("team"),params.get("teamProvider")||activeProvider,params.get("teamLeague")||activeLeague,params.get("teamName")||"");
    }
  } catch { $("leaguelist").textContent = "Lig verisi alınamadı."; $("fixturelist").textContent = "Fikstür servisine ulaşılamadı."; }
}
function drawLeagueList() {
  const q = $("leagueSearch").value.toLocaleLowerCase("tr-TR");
  const list = competitions.filter(x => competitionLabel(x).toLocaleLowerCase("tr-TR").includes(q)).slice(0, 80);
  $("leaguelist").innerHTML = list.length ? list.map(x => `<div class="league"><span>${esc(competitionLabel(x))}</span><small>${x.season}</small></div>`).join("") : "Aramayla eşleşen lig yok.";
}
function statusLabel(m) {
  if (m.status === "disputed") return '<span class="status-live">KAYNAKLAR ÇELİŞİYOR</span>';
  if (m.status === "live") return '<span class="status-live">● CANLI</span>';
  if (m.status === "finished") return '<span class="status-done">BİTTİ</span>';
  if (m.status === "scheduled") return "Başlamadı";
  return "Durum doğrulanmadı";
}
function matchMarkup(m) {
  const score = m.score ? `${m.score.home} - ${m.score.away}` : "—";
  return `<div class="match"><div>${m.homeLogo ? `<img src="${esc(m.homeLogo)}" width="18" height="18" loading="lazy" alt="" style="object-fit:contain;vertical-align:middle;margin-right:4px">` : ""}${esc(m.home)}</div><div class="score">${score}</div><div class="away">${m.awayLogo ? `<img src="${esc(m.awayLogo)}" width="18" height="18" loading="lazy" alt="" style="object-fit:contain;vertical-align:middle;margin-right:4px">` : ""}${esc(m.away)}</div><div class="meta2"><span>${m.dateOnly?new Date(m.date).toLocaleDateString("tr-TR"):new Date(m.date).toLocaleString("tr-TR")}</span><span>${statusLabel(m)}</span></div></div>`;
}
async function loadLeague() {
  const option = $("competition").selectedOptions[0]; if (!option || !option.value) return;
  const league = option.value, season = option.dataset.season, provider = option.dataset.provider || "openligadb";
  activeProvider = provider; activeLeague = league;
  const shareUrl = new URL(location.href); shareUrl.searchParams.set("league",league); shareUrl.searchParams.set("provider",provider); shareUrl.searchParams.set("season",season); shareUrl.searchParams.delete("team"); history.replaceState({}, "", shareUrl);
  updatePageMeta(`DOKSAN | ${option.textContent.trim()}`,`${option.textContent.trim()} fikstürü, puan durumu, maç sonuçları ve takım sayfaları.`);
  $("fixturelist").textContent = "Maçlar yükleniyor…"; $("standings").textContent = "Puan durumu yükleniyor…";
  try {
    const d=await api(`/api/league/${encodeURIComponent(provider)}/${encodeURIComponent(league)}?season=${encodeURIComponent(season)}`);
    const matches=d.fixtures||[], rows=d.standings||[];
    const now=Date.now();
    const live=matches.filter(x=>x.status==="live");
    const upcoming=matches.filter(x=>x.status==="scheduled"&&Date.parse(x.date)>=now).slice(0,7);
    const finished=matches.filter(x=>x.status==="finished").slice(-5).reverse();
    const uncertain=matches.filter(x=>x.status==="unverified").slice(-4).reverse();
    const selected=[...live,...upcoming,...finished,...uncertain].filter((x,i,a)=>a.findIndex(y=>y.id===x.id)===i).slice(0,14);
    const fixtureSource=d.sources?.fixtures||"bilinmiyor", tableSource=d.sources?.standings||"bilinmiyor";
    $("fixturelist").innerHTML=`<div class="footnote">Lig: ${esc(d.name||competitionLabel({name:league}))} · Kaynak: ${esc(fixtureSource)}</div>`+(selected.length?selected.map(matchMarkup).join(""):'<div class="muted">Bu lig için doğrulanmış maç verisi bulunamadı.</div>');
    $("standings").innerHTML=`<div class="footnote">Puan kaynağı: ${esc(tableSource)}</div>`+(rows.length?`<div class="tablewrap"><table><thead><tr><th>#</th><th>Takım</th><th>O</th><th>G</th><th>B</th><th>M</th><th>AV</th><th>P</th></tr></thead><tbody>${rows.map((x,i)=>`<tr><td>${x.position||i+1}</td><td>${esc(x.teamName)}</td><td>${x.matches??"—"}</td><td>${x.won??"—"}</td><td>${x.draw??"—"}</td><td>${x.lost??"—"}</td><td>${x.goalDiff??"—"}</td><td><b>${x.points??"—"}</b></td></tr>`).join("")}</tbody></table></div>`:'<div class="muted">Kaynak bu lig için doğrulanabilir puan tablosu sunmuyor.</div>');
    const teams=new Map();
    for(const m of matches){if(m.homeId)teams.set(String(m.homeId),{id:m.homeId,name:m.home,logo:m.homeLogo});if(m.awayId)teams.set(String(m.awayId),{id:m.awayId,name:m.away,logo:m.awayLogo});}
    for(const x of rows){const teamId=x.teamId||x.teamInfoId;if(teamId)teams.set(String(teamId),{id:teamId,name:x.teamName,logo:x.crest||x.teamIconUrl||null});}
    $("teamlist").innerHTML=teams.size?`<div class="teamgrid">${[...teams.values()].sort((a,b)=>a.name.localeCompare(b.name,"tr")).map(x=>`<button class="teamcard" data-team="${esc(x.id)}" data-team-name="${esc(x.name)}">${x.logo?`<img src="${esc(x.logo)}" alt="" loading="lazy">`:""}${esc(x.name)}</button>`).join("")}</div>`:'<div class="empty">Bu lig için takım listesi bulunamadı.</div>';
    document.querySelectorAll("[data-team]").forEach(b=>b.addEventListener("click",()=>loadTeam(b.dataset.team,provider,league,b.dataset.teamName)));
    $("shareLeague").onclick=()=>shareCurrentPage("DOKSAN · "+(d.name||league));
  } catch {
    $("fixturelist").innerHTML='<div class="empty">Lig fikstürü hiçbir uygun kaynaktan doğrulanamadı.</div>';
    $("standings").innerHTML='<div class="empty">Puan tablosu hiçbir uygun kaynaktan doğrulanamadı.</div>';
    $("teamlist").innerHTML='<div class="empty">Takım listesi şu anda alınamıyor.</div>';
  }
}
async function loadTeam(id, provider = activeProvider, league = activeLeague, name = "") {
  $("teamdetail").innerHTML = '<div class="empty">Takım bilgileri yükleniyor…</div>';
  const shareUrl = new URL(location.href); shareUrl.searchParams.set("team",id); shareUrl.searchParams.set("teamProvider",provider); shareUrl.searchParams.set("teamLeague",league); if(name)shareUrl.searchParams.set("teamName",name); history.replaceState({}, "", shareUrl);
  try {
    const d = await api(`/api/teams/${encodeURIComponent(id)}?provider=${encodeURIComponent(provider)}&league=${encodeURIComponent(league)}`);
    let profile = null;
    if(name || d.team?.name) profile = await api(`/api/team-profile?name=${encodeURIComponent(name || d.team.name)}`).catch(()=>null);
    const p=profile?.team;
    updatePageMeta(`DOKSAN | ${p?.name||d.team.name}`,`${p?.name||d.team.name} takım profili, son maçlar, gelecek maçlar ve kadro bilgileri.`);
    const roster=profile?.players||[];
    const website=p?.website && /^https?:\/\//i.test(p.website) ? `<a href="${esc(p.website.startsWith("http")?p.website:"https://"+p.website)}" target="_blank" rel="noopener noreferrer">Resmî site</a>` : "";
    const info=p ? `<div class="teamfacts">${p.stadium?`<span><b>Stadyum:</b> ${esc(p.stadium)}</span>`:""}${p.location?`<span><b>Şehir:</b> ${esc(p.location)}</span>`:""}${p.formed?`<span><b>Kuruluş:</b> ${esc(p.formed)}</span>`:""}${p.manager?`<span><b>Teknik direktör:</b> ${esc(p.manager)}</span>`:""}${website}</div>${p.description?`<p class="teamdesc">${esc(p.description)}</p>`:""}`:"";
    const squad=roster.length?`<h4>Kadro</h4><div class="squadgrid">${roster.map(x=>`<div class="player">${x.photo?`<img src="${esc(x.photo)}" alt="" loading="lazy">`:""}<b>${esc(x.name)}</b><small>${esc(x.position||"")}${x.number?` · #${esc(x.number)}`:""}</small></div>`).join("")}</div>`:"";
    $("teamdetail").innerHTML = `<div class="teamdetail"><div class="teamtitle">${p?.badge?`<img src="${esc(p.badge)}" width="42" height="42" alt="">`:d.team.logo?`<img src="${esc(d.team.logo)}" width="42" height="42" alt="">`:""}<div><h3>${esc(p?.name||d.team.name)}</h3><div class="muted">Takım profili · ${esc(d.provider)}${p?" + TheSportsDB":""}</div></div></div>${info}${squad}<div class="teamsection"><h4>Son ve gelecek maçlar</h4>${(d.matches || []).map(matchMarkup).join("")}</div><button class="tab" id="shareTeam" type="button">Takım sayfasını paylaş</button><div class="footnote">Takım bilgileri ve kadro TheSportsDB üzerinden eklenir; bulunmayan alanlar gösterilmez. Maç kaynağı: ${esc(d.provider)}.</div></div>`;
    $("shareTeam")?.addEventListener("click",()=>shareCurrentPage("DOKSAN · "+(p?.name||d.team.name)));
  } catch { $("teamdetail").innerHTML = '<div class="empty">Bu takım için doğrulanmış detay verisi alınamadı.</div>'; }
}
async function shareCurrentPage(title="DOKSAN") {
  const data={title,text:"DOKSAN futbol portalı",url:location.href};
  try { if(navigator.share) await navigator.share(data); else if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(location.href);alert("Bağlantı kopyalandı.");} }
  catch {}
}

document.querySelectorAll("[data-region]").forEach(b => b.addEventListener("click", () => { region = b.dataset.region; category = "all"; document.querySelectorAll("[data-region], [data-category]").forEach(x => x.classList.toggle("active", x === b)); drawNews(); }));
document.querySelectorAll("[data-category]").forEach(b => b.addEventListener("click", () => { category = b.dataset.category; region = "all"; document.querySelectorAll("[data-region], [data-category]").forEach(x => x.classList.toggle("active", x === b)); drawNews(); }));
$("q").addEventListener("input", () => { drawNews(); $("leagueSearch").value=$("q").value; drawLeagueList(); document.querySelectorAll(".teamcard").forEach(card=>card.classList.toggle("hidden",!card.dataset.teamName.toLocaleLowerCase("tr-TR").includes($("q").value.toLocaleLowerCase("tr-TR")))); }); $("competition").addEventListener("change", loadLeague); $("leagueSearch").addEventListener("input", drawLeagueList); $("year").textContent = new Date().getFullYear();
loadNews(); loadCompetitions(); loadLive(); setInterval(loadNews, 60000); setInterval(loadLive, 60000); setInterval(loadCompetitions, 10 * 60 * 1000); setInterval(loadLeague, 5 * 60 * 1000);
