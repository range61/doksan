DOKSAN v8 — TÜRKÇE FUTBOL PORTALI
=================================

ÜRÜN KAPSAMI
- Türkiye futbolu öncelikli, dünya futbolunu kapsayan mobil web portalı
- Son dakika, haber, transfer gündemi, canlı skor, maç merkezi, fikstür, puan tablosu ve takım profilleri
- Arama: haber, lig ve yüklenmiş takım listeleri
- Takım ve lig seçimi URL üzerinden paylaşılabilir/yeniden açılabilir
- PWA: destekleyen telefonlarda ana ekrana eklenebilir
- SEO: açıklama, Open Graph/Twitter meta etiketleri, JSON-LD, robots.txt ve sitemap.xml
- Takım sayfalarında maç geçmişi/takvimi; varsa stadyum, şehir, kuruluş, teknik direktör, kadro ve rozet bilgileri

HABER VE TRANSFER
- 15 RSS kaynağı; Türkiye ve dünya haberleri
- Kaynaklar birbirinden bağımsız çekilir; bir feed çalışmazsa diğerleri çalışır
- Otomatik 10 dakikalık yenileme (sunucu açık olduğu sürece)
- Aynı haberler exact + başlık benzerliği ve 36 saatlik zaman aralığıyla tekilleştirilir
- Birden fazla kaynaktaki haberin kaynak adedi gösterilir; asıl haber linki korunur
- Transfer filtresi; açıkça resmîlik bildiren başlıklar “RESMÎ İFADE”, diğerleri “TRANSFER GÜNDEMİ” olarak etiketlenir
- Transfer sınıflandırması başlık/özet anahtar kelimelerine dayanır; bağımsız doğrulama değildir. Resmî duyuru sayılabilmesi için başlıkta/özetinde açık bir resmîlik ifadesi gerekir.

CANLI SKOR / ÇOKLU KAYNAK
1. ESPN: ücretsiz ve anahtarsız herkese açık skorboard uç noktaları; resmi bir geliştirici SLA'sı veya garantili uptime sunulmaz.
2. SportScore: ücretsiz futbol maç widget uç noktası; kullanım şartı gereği görünür “Powered by SportScore” bağlantısı vardır.
3. football-data.org: isteğe bağlı yedek. Ücretsiz kayıt/token gerekir; kapsam ve hız sınırları sağlayıcı planına bağlıdır.
- ESPN ve SportScore ayrı canlı kaynaklardır. football-data.org token eklenirse üçüncü bağımsız sağlayıcı denenir. OpenFootball canlı skor kaynağı değil, yalnızca desteklediği Avrupa liglerinde fikstür/sonuç yedeğidir.
- Bir kaynağın erişilememesi diğerini durdurmaz. Kaynak sonuçları birleştirilir; farklı skor/durum görülürse skor saklanır ve uyuşmazlık gösterilir.
- Aynı sağlayıcının farklı uç noktaları ayrı bağımsız kaynak gibi sayılmaz.
- TheSportsDB ücretsiz API'si takım bilgisi/kadro zenginleştirmesi için kullanılır; ücretsiz planın canlı skor erişimi yoktur. Bu yüzden canlı skor sağlayıcısı olarak sayılmaz.
- OpenLigaDB fikstür, geçmiş sonuç ve puan tablosu için kullanılır; topluluk katkılıdır ve tüm liglerde anlık veri garantisi yoktur.
- Hiçbir sağlayıcı her ülke/lig için eksiksiz veri garantisi vermez. Kaynakta bulunmayan veri uydurulmaz.

FİKSTÜR VE PUAN DURUMU
- OpenLigaDB, ESPN ve (token varsa) football-data.org arasında yedekli sorgulama
- Puan tabloları maç/galibiyet/beraberlik/mağlubiyet/puan/averaj aritmetiğiyle doğrulanır
- Bir kaynak başarısızsa eşleştirilebilen diğer kaynak denenir
- Türkiye 1. Lig, kullanılan ücretsiz sağlayıcılardan biri veri sunarsa görünür; bulunmayan lig uydurulmaz
- 2. ve 3. Lig kapsamı hedef kapsam dışında

TAKIM PROFİLLERİ
- Seçilen ligin maç verisinden takım listesi
- Takımın son/gelecek maçları
- TheSportsDB ücretsiz v1 aramasıyla ek takım rozeti, stadyum, şehir, kuruluş yılı, teknik direktör, açıklama ve sınırlı kadro bilgisi (veri bulunursa)
- Takım sayfası URL parametreleriyle paylaşılabilir
- TheSportsDB ücretsiz API limitleri nedeniyle bazı takımlarda profil/kadro alanları boş kalabilir; maç bilgisi ayrı veri sağlayıcıdan gelir.

API
GET /api/health
GET /api/news?region=turkey|world&category=transfer|breaking&q=kelime
GET /api/transfers?q=kelime
GET /api/live
GET /api/competitions
GET /api/fixtures?league=KOD&season=2026&provider=espn|openligadb|football-data
GET /api/standings?league=KOD&season=2026&provider=espn|openligadb|football-data
GET /api/league/PROVIDER/KOD?season=2026
GET /api/teams/ID?provider=espn|openligadb|football-data&league=espn-league-code
GET /api/team-profile?name=Takım%20Adı
GET /api/admin/source-health (ADMIN_TOKEN gerekir)
GET /robots.txt
GET /sitemap.xml

KURULUM
- Node.js 20.12+ (önerilen Node 22)
- npm install
- .env.example dosyasını .env olarak kopyalayın (isteğe bağlı)
- npm start
- http://localhost:3000
- Kontrol: npm run check
- Test: npm test

İSTEĞE BAĞLI FOOTBALL-DATA.ORG
- FOOTBALL_DATA_TOKEN değişkenine token eklenirse üçüncü futbol veri sağlayıcısı devreye girer.
- Token olmadan ESPN + SportScore canlı skor; OpenLigaDB + ESPN fikstür/puan verisi kullanılır.
- Ücretsiz planın lig kapsamı, erişim hızı ve maç verisi limiti sağlayıcı tarafından belirlenir.

BİLDİRİMLER
- Kullanıcı izin verirse portal açıkken skor değişikliklerinde tarayıcı bildirimi.
- Sekme/uygulama kapalıyken gerçek push bildirimleri bu sürümde yoktur; bunun için VAPID anahtarı ve push sunucusu gerekir.

YAYINLAMA / SINIRLAR
- Bu ZIP kaynak kod ve Node.js sunucu paketidir; canlı alan adına yayınlanmış değildir.
- 7/24 erişim için Node.js/Docker barındırma gerekir. Ücretsiz hostinglerde uyku/kota/çalışma süresi kısıtları olabilir.
- Bu ortamda dış API'lerin çalışma anı uçtan uca testi yapılamadı; npm install ve gerçek API testleri barındırma/Node ortamında yapılmalıdır.
- RSS/API sağlayıcılarının endpointleri ve kullanım koşulları değişebilir; source-health endpointi yöneticinin kaynak kontrolü içindir.
